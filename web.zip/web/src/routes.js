import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';

import Feed from './Pages/index';
import Cooming_soon from './Pages/coming-soon'
import company_profile from './Pages/company-profile'
import components from './Pages/components'
import connection from './Pages/connection'
import contact from './Pages/contact'
import edit_profile from './Pages/edit-profile'
import faq from './Pages/faq'
import forgot_password from './Pages/forgot-password'
import job_profile from './Pages/job-profile'
import jobs from './Pages/jobs'
import maintence from './Pages/maintence'
import messages from './Pages/messages'
import not_found from './Pages/not-found'
import notification from './Pages/notifications'
import pricing from './Pages/pricing'
import privacy from './Pages/privacy'
import profile from './Pages/profile'
import sign_int from './Pages/sign-in'
import sign_up from './Pages/sign-up'
import terms from './Pages/terms'


export default function Routes() {
    return(
<BrowserRouter>
<Switch>
<Route path='/' exact component={Feed}   />
<Route path='/cooming_soon' component={Cooming_soon}/>
<Route path='/company-profile' component={company_profile}/>
<Route path='/components' component={components}/>
<Route path='/connection' component={connection}/>
<Route path='/contact' component={contact}/>
<Route path='/edit-profile' component={edit_profile}/>
<Route path='/faq' component={faq}/>
<Route path='/forgot-password' component={forgot_password}/>
<Route path='/jobs' component={jobs}/>
<Route path='/job-profile' component={job_profile}/>
<Route path='/maintence' component={maintence}/>
<Route path='/messages' component={messages}/>
<Route path='/not-found' component={not_found}/>
<Route path='/notification' component={notification}/>
<Route path='/pricing' component={pricing}/>
<Route path='/privacy' component={privacy}/>
<Route path='/profile' component={profile}/>
<Route path='/sign-in' component={sign_int}/>
<Route path='/sign-up' component={sign_up}/>
<Route path='/terms' component={terms}/>
</Switch>

</BrowserRouter>
    );
}
