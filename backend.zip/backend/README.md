# A FAZER

1. colocar localização ok
2. array curriculo inputs 
3. perfil profissional e pessoal 
4. implementar `tamber`
5. gatway pagamento com `apple pay` e `google pay` 
6. implementar ao frontend
    a. comecando com o `mobile` 
    b. implementando push notification 
    c. usando useeffect 
7. partir para o frontend 
    a. implementando use effect 
    b. notification
8. `implementar` analise de curriculo e devolucao de valor em porcentagem 
9. implementar `seguranca com github` 
10. testar e `depurar` codigos 
11. fazer `deploy`
12. `entregar` para testes

# INICIAR COMPRE AQUI E SOCIGAMES COM MESMAS TECNOLOGIAS REACT NATIVE, REACTJS E NODEJS 


`VALEU` 