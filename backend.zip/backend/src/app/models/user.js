const mongoose = require('../../database')
const bcrypt = require('bcryptjs')
const aws = require("aws-sdk");
const fs = require("fs");
const PointSchema = require('./utils/PointSchema');
const path = require("path");
const {
  promisify
} = require("util");

const s3 = new aws.S3();


const ImageSchema = new mongoose.Schema({
    name: String,
    size: Number,
    key: String,
    url: String,
  });
const InputSchema = new mongoose.Schema({
    name:{
        type:String,
        require:true,
    },

})

const UserSchema = new mongoose.Schema({
    email:{
        type:String,
        unique:true,
        required:true,
        lowercase:true,
    },
    password:{
        type:String,
        required:true,
        select:false,
    },
    passwordResetToken:{
        type:String,
        select:false
    },
    passwordResetExpires:{
        type:Date,
        select:false
    },
    createdAd:{
        type:Date,
        default:Date.now
    },
    avatarUrl:ImageSchema,
    inputs:InputSchema,
    location: {
      type: PointSchema,
      index: '2dsphere'
    }
  
})

UserSchema.pre('save', async function(next){
    const hash = await bcrypt.hash(this.password,10)
    this.password = hash
    
    next()
})

ImageSchema.pre("save", function () {
    if (!this.url) {
      this.url = `${process.env.APP_URL}/files/${this.key}`;
    }
  });
  
  ImageSchema.pre("remove", function () {
    if ('local' === "s3") {
      return s3
        .deleteObject({
          Bucket: 'serverem',
          Key: this.key
        })
        .promise()
        .then(response => {
          console.log(response.status);
        })
        .catch(response => {
          console.log(response.status);
        });
    } else {
      return promisify(fs.unlink)(
        path.resolve(__dirname, "..", "..", "tmp", "uploads", this.key)
      );
    }
  });
  

  
const User = mongoose.model('User', UserSchema)

module.exports = User