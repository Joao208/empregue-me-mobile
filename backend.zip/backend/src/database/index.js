const mongoose = require('mongoose')

mongoose.connect('mongodb+srv://Joao:wakandaforever@cluster0-w4dvd.mongodb.net/test?retryWrites=true&w=majority', 
{useNewUrlParser: true, 
useUnifiedTopology: true,
useFindAndModify:false,
useCreateIndex:true,
}
)
mongoose.Promise = global.Promise

module.exports = mongoose