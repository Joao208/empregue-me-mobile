import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';

import Feed from './Pages/index';
import Cooming_soon from './Pages/coming-soon'
import company_profile from './Pages/company-profile'
import components from './Pages/components'
import connection from './Pages/connection'
import contact from './Pages/contact'
import edit_profile from './Pages/edit-profile'
import faq from './Pages/faq'
import forgot_password from './Pages/forgot-password'
import job_profile from './Pages/job-profile'
import jobs from './Pages/jobs'
import maintence from './Pages/maintence'
import messages from './Pages/messages'
import not_found from './Pages/not-found'
import notification from './Pages/notifications'
import pricing from './Pages/pricing'
import privacy from './Pages/privacy'
import profile from './Pages/profile'
import sign_int from './Pages/sign-in'
import sign_up from './Pages/sign-up'
import terms from './Pages/terms'


export default function Routes() {
    return(
<BrowserRouter>
<Switch>
<Route path='/dark'  component={Feed}   />
<Route path='/cooming_soon-dark' component={Cooming_soon}/>
<Route path='/company-profile-dark' component={company_profile}/>
<Route path='/components-dark' component={components}/>
<Route path='/connection-dark' component={connection}/>
<Route path='/contact-dark' component={contact}/>
<Route path='/edit-profile-dark' component={edit_profile}/>
<Route path='/faq-dark' component={faq}/>
<Route path='/forgot-password-dark' component={forgot_password}/>
<Route path='/jobs-dark' component={jobs}/>
<Route path='/job-profile-dark' component={job_profile}/>
<Route path='/maintence-dark' component={maintence}/>
<Route path='/messages-dark' component={messages}/>
<Route path='/not-found-dark' component={not_found}/>
<Route path='/notification-dark' component={notification}/>
<Route path='/pricing-dark' component={pricing}/>
<Route path='/privacy-dark' component={privacy}/>
<Route path='/profile-dark' component={profile}/>
<Route path='/sign-in-dark' component={sign_int}/>
<Route path='/sign-up-dark' component={sign_up}/>
<Route path='/terms-dark' component={terms}/>
</Switch>

</BrowserRouter>
    );
}
