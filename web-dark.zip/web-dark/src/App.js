import React from 'react';

import Routes from '../src/routes'

function App() {
  return (
    <div>
      <Routes/>
    </div>

    );
}

export default App;
