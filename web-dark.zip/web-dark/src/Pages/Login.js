import React, { useEffect, useState } from 'react';
import api from '../services/api';

import DevForm from '../components/DevForm';

function Login({history}) {


  const [devs, setDevs] = useState([]);

  useEffect(() => {
    async function loadDevs() {
      const response = await api.get('/devs');

      setDevs(response.data);
    }

    loadDevs();
  }, []);

  async function handleAddDev(data) {
    const response = await api.post('/devs', data);
    setDevs([...devs, response.data])
    history.push('Feed')
  }

  return (
      <>
    <div id="app">
      <aside>
        <strong>Cadastrar</strong>
        <DevForm onSubmit={handleAddDev} />
      </aside>
      <main>
      </main>
    </div>
    </>
  );
}

export default Login;
